// backend/server.js
import express from 'express';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';

// Configuración de variables de entorno
dotenv.config();

// Inicialización del servidor
const app = express();
const port = process.env.PORT || 3000;

// Configuración de middleware
app.use(express.json());

// Inicialización de Supabase
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);

// Inicio del servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
