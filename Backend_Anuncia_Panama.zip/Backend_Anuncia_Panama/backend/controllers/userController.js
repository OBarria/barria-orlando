// backend/controllers/userController.js
import supabase from '../config/supabase.js';

// Obtener perfil de usuario
export const getUserProfile = async (req, res) => {
  const userId = req.user.id;

  const { data, error } = await supabase.from('users').select('*').eq('id', userId).single();

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  res.status(200).json(data);
};
