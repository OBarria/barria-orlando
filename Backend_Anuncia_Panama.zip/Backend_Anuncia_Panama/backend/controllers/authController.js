// backend/controllers/authController.js
import supabase from '../config/supabase.js';
import jwt from 'jsonwebtoken';

// Registro de usuario
export const registerUser = async (req, res) => {
  const { email, password, username } = req.body;

  // Validaciones
  if (!email || !password || !username) {
    return res.status(400).json({ message: 'Todos los campos son obligatorios' });
  }

  // Registro en Supabase
  const { user, error } = await supabase.auth.signUp({ email, password });

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  // Almacenar información adicional del usuario en la base de datos
  await supabase.from('users').insert([{ id: user.id, username }]);

  res.status(201).json({ message: 'Usuario registrado exitosamente' });
};

// Inicio de sesión
export const loginUser = async (req, res) => {
  const { email, password } = req.body;

  // Validaciones
  if (!email || !password) {
    return res.status(400).json({ message: 'Todos los campos son obligatorios' });
  }

  // Autenticación en Supabase
  const { user, error } = await supabase.auth.signIn({ email, password });

  if (error) {
    return res.status(400).json({ message: error.message });
  }

  // Generar token JWT
  const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });

  res.status(200).json({ token });
};
