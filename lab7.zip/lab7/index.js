const express = require('express');
const app = express();
const port = 3000;

// Función para calcular la serie Fibonacci
function fibonacci(n) {
    let fibSeries = [];
    let a = 0, b = 1, next;
    
    for (let i = 0; i < n; i++) {
        fibSeries.push(a);
        next = a + b;
        a = b;
        b = next;
    }
    
    return fibSeries;
}

// Endpoint que retorna la serie Fibonacci
app.get('/fibonacci/:number', (req, res) => {
    const number = parseInt(req.params.number, 10);

    if (isNaN(number) || number < 1) {
        return res.status(400).json({ error: 'Please provide a positive integer' });
    }

    const fibSeries = fibonacci(number);
    res.json(fibSeries);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
