# bun-add-express

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run touch index.js
```

This project was created using `bun init` in bun v1.1.12. [Bun](https://bun.sh) is a fast all-in-one JavaScript runtime.
