//AnunciaPanama/anuncia-panama-frontend/src/app/page.js

export default function HomePage() {
  return (
      <h1 className="text-4xl font-bold">Welcome to the Home Page</h1>
  );
}
