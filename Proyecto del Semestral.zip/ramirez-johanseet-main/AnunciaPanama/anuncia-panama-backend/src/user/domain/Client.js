class Client {
    constructor(id, fullName, dateOfBirth, gender, createdAt) {
      this.id = id;
      this.fullName = fullName;
      this.dateOfBirth = dateOfBirth;
      this.gender = gender;
      this.createdAt = createdAt;
    }
  }
  
  export default Client;
  