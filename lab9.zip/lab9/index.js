const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());

// Función para calcular la serie de Fibonacci
function fibonacci(n) {
    let fibSeries = [0, 1];
    for (let i = 2; i < n; i++) {
        fibSeries.push(fibSeries[i - 1] + fibSeries[i - 2]);
    }
    return fibSeries.slice(0, n);
}

// Endpoint que retorna la serie de Fibonacci
app.get('/fibonacci/:number', (req, res) => {
    const number = parseInt(req.params.number, 10);
    if (isNaN(number) || number <= 0) {
        return res.status(400).json({ error: 'Invalid number' });
    }
    const fibSeries = fibonacci(number);
    res.json(fibSeries);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
