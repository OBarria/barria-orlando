document.getElementById('fibonacciForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const number = document.getElementById('numberInput').value;
  const fibonacciCardsContainer = document.getElementById('fibonacciCardsContainer');
  fibonacciCardsContainer.innerHTML = ''; // Limpiar contenedor antes de mostrar nuevos datos

  try {
      const response = await fetch(`http://localhost:3000/fibonacci/${number}`);
      if (!response.ok) {
          throw new Error('Número inválido');
      }
      const data = await response.json();
      data.forEach(num => {
          const card = document.createElement('div');
          card.className = 'w3-card-4 w3-center';
          card.innerHTML = `<div class="response-numbers">${num}</div>`;
          fibonacciCardsContainer.appendChild(card);
      });
  } catch (error) {
      const errorMessage = document.createElement('div');
      errorMessage.className = 'w3-card-4 w3-center';
      errorMessage.innerHTML = `<div class="response-numbers" style="color:red;">Error: ${error.message}</div>`;
      fibonacciCardsContainer.appendChild(errorMessage);
  }
});
